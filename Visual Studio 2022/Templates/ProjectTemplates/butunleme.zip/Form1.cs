﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Runtime.CompilerServices;
using System.Net.NetworkInformation;

namespace $safeprojectname$
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: Bu kod satırı 'finalDataSet.ISLEM' tablosuna veri yükler. Bunu gerektiği şekilde taşıyabilir, veya kaldırabilirsiniz.
            this.iSLEMTableAdapter.Fill(this.finalDataSet.ISLEM);
            // TODO: Bu kod satırı 'finalDataSet.KREDI' tablosuna veri yükler. Bunu gerektiği şekilde taşıyabilir, veya kaldırabilirsiniz.
            this.kREDITableAdapter.Fill(this.finalDataSet.KREDI);
            // TODO: Bu kod satırı 'finalDataSet.HESAP' tablosuna veri yükler. Bunu gerektiği şekilde taşıyabilir, veya kaldırabilirsiniz.
            this.hESAPTableAdapter.Fill(this.finalDataSet.HESAP);
            // TODO: Bu kod satırı 'finalDataSet.MUSTERI' tablosuna veri yükler. Bunu gerektiği şekilde taşıyabilir, veya kaldırabilirsiniz.
            this.mUSTERITableAdapter.Fill(this.finalDataSet.MUSTERI);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=DESKTOP-JHBLRGR;Initial Catalog=final;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string insertQuery = "INSERT INTO MUSTERI (TCNo, Ad, Soyad, DogumTarihi, Telefon, Eposta) " +
                    "VALUES (@p1, @p2, @p3, @p4, @p5, @p6)";

                using (SqlCommand command = new SqlCommand(insertQuery, connection))
                {
                    command.Parameters.AddWithValue("@p1", textBox1.Text);
                    command.Parameters.AddWithValue("@p2", textBox2.Text);
                    command.Parameters.AddWithValue("@p3", textBox3.Text);
                    command.Parameters.AddWithValue("@p4", textBox4.Text);
                    command.Parameters.AddWithValue("@p5", textBox5.Text);
                    command.Parameters.AddWithValue("@p6", textBox6.Text);

                    command.ExecuteNonQuery();
                }
            }

            
            this.mUSTERITableAdapter.Fill(this.finalDataSet.MUSTERI);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=DESKTOP-JHBLRGR;Initial Catalog=final;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string deleteQuery = "DELETE FROM MUSTERI WHERE TCNo = @p1";

                using (SqlCommand command = new SqlCommand(deleteQuery, connection))
                {
                    command.Parameters.AddWithValue("@p1", textBox1.Text);

                    command.ExecuteNonQuery();
                }
            }

            // Refresh the DataGridView
            this.mUSTERITableAdapter.Fill(this.finalDataSet.MUSTERI);
        
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=DESKTOP-JHBLRGR;Initial Catalog=final;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string insertQuery = "INSERT INTO HESAP (HesapNo, Tur, BankaKod, SubeNo, TCNo) " +
                    "VALUES (@p1, @p2, @p3, @p4, @p5)";

                using (SqlCommand kaydeet = new SqlCommand(insertQuery, connection))
                {
                    kaydeet .Parameters.AddWithValue("@p1", textBox7.Text);
                    kaydeet .Parameters.AddWithValue("@p2", textBox8.Text);
                    kaydeet .Parameters.AddWithValue("@p3", textBox9.Text);
                    kaydeet .Parameters.AddWithValue("@p4", textBox10.Text);
                    kaydeet .Parameters.AddWithValue("@p5", textBox11.Text);

                    kaydeet .ExecuteNonQuery();
                }
            }

            this.hESAPTableAdapter.Fill(this.finalDataSet.HESAP);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=DESKTOP-JHBLRGR;Initial Catalog=final;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string deleteQuery = "DELETE FROM HESAP WHERE HesapNo = @p1";

                using (SqlCommand command = new SqlCommand(deleteQuery, connection))
                {
                    command.Parameters.AddWithValue("@p1", textBox7.Text);

                    command.ExecuteNonQuery();
                }
            }

            // Refresh the DataGridView2
            this.hESAPTableAdapter.Fill(this.finalDataSet.HESAP);
        }

        private void textBox12_TextChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {

            string tcNo = textBox12.Text;
            SqlConnection connection = new SqlConnection("Data Source=DESKTOP-JHBLRGR;Initial Catalog=final;Integrated Security=True");
            SqlCommand command = new SqlCommand("SELECT * FROM KREDI WHERE TCNo = @tcNo", connection);
            command.Parameters.AddWithValue("@tcNo", tcNo);
            if (string.IsNullOrEmpty(tcNo))
            {
                command = new SqlCommand("SELECT * FROM KREDI", connection);
            }
            else
            {
                command = new SqlCommand("SELECT * FROM KREDI WHERE TCNo = @tcNo", connection);
                command.Parameters.AddWithValue("@tcNo", tcNo);
            }
            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                DataTable dataTable = new DataTable();
                dataTable.Load(reader);
                dataGridView7.DataSource = dataTable;
                reader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }

        }

        private void button6_Click(object sender, EventArgs e)
        {
            string tcNo = textBox13.Text;
            SqlConnection connection = new SqlConnection("Data Source=DESKTOP-JHBLRGR;Initial Catalog=final;Integrated Security=True");
            SqlCommand command = new SqlCommand("SELECT * FROM ISLEM WHERE TCNo = @tcNo", connection);
            command.Parameters.AddWithValue("@tcNo", tcNo);
            if (string.IsNullOrEmpty(tcNo))
            {
                command = new SqlCommand("SELECT * FROM ISLEM", connection);
            }
            else
            {
                command = new SqlCommand("SELECT * FROM ISLEM WHERE TCNo = @tcNo", connection);
                command.Parameters.AddWithValue("@tcNo", tcNo);
            }
            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                DataTable dataTable = new DataTable();
                dataTable.Load(reader);
                dataGridView8.DataSource = dataTable;
                reader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }
    }
}

